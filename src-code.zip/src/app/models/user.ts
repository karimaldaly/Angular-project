export default class Machine {
    area:string ="";
    sensorState: string = "";
    buzzerState: string = "";
    humanDetected?: number ;
}
