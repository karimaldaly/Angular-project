import { Injectable } from "@angular/core";
import { addDoc, Firestore, collection, doc, updateDoc, setDoc, getDoc } from "@angular/fire/firestore";
import Machine from "../models/user";

@Injectable({ providedIn: 'root' })
export class ServerService {

    constructor(private db: Firestore) {

    }

    addNewDocument(machine: Machine) {
        const dbInstance = collection(this.db, "cars");
        return addDoc(dbInstance, { ...machine });
    }

    addNewDocumentWithSpecificID(machine: Machine) {
        const dbInstance = collection(this.db, "cars");
        return setDoc(doc(dbInstance, "custome-id"), { ...machine });
    }

    updateDocument(id: string, sensorState: string, buzzerState: string, humanDetected?:number) {
        const dataUpdate = doc(this.db, "cars", id);
        console.log(dataUpdate);
        return updateDoc(dataUpdate, {
          sensorState: sensorState,
          buzzerState: buzzerState,
          humanDetected:humanDetected
        });
    }

    getDocument(id: string) {
        const dbInstance = collection(this.db, "cars");
        return getDoc(doc(dbInstance, id));
    }


    getAll() {
        return collection(this.db, "cars");
    }
}
