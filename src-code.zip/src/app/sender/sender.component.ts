import { Component, OnInit } from '@angular/core';
import { DocumentReference, DocumentSnapshot } from '@angular/fire/firestore';
import Machine from '../models/user';
import { ServerService } from '../services/server.service';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-sender',
  templateUrl: './sender.component.html',
  styleUrls: ['./sender.component.css']
})
export class SenderComponent {
  sensorState: string = '';
  buzzerState: string = '';
  humanDetected?: number ;
  machine: Machine;

  ref?: string;

  constructor(private serverService: ServerService) {
    this.machine = new Machine();
  }


  addNewDocument() {
    this.machine.sensorState = this.sensorState;
    this.machine.buzzerState = this.buzzerState;
    this.machine.humanDetected = this.humanDetected;

    this.serverService.addNewDocument(this.machine).then((ref: DocumentReference) => {
      console.log("Document Id: " + ref.id);
      this.ref = ref.id
    });
  }

  updateDocument() {
    this.machine.sensorState = this.sensorState;
    this.machine.buzzerState = this.buzzerState;
    this.machine.humanDetected = this.humanDetected;
    if (this.ref != null) {

      this.serverService.updateDocument(this.ref, this.sensorState, this.buzzerState,this.humanDetected).then(() => {
        alert("updated");
      });
    } else {
      alert("document Id is required")
    }
  }

  getDocument() {
    if (this.ref != null) {
      this.serverService.getDocument(this.ref).then((data: DocumentSnapshot) => {
        this.sensorState = data?.data()?.['sensorState'];
        this.buzzerState = data?.data()?.['buzzerState'];
        this.humanDetected = data?.data()?.['humanDetected'];
        this.ref = data.id;
      });
    } else {
      alert("document Id is required")
    }
  }

  reset() {
    this.sensorState = null!
    this.buzzerState = null!
    this.humanDetected = null!
    this.ref = null!
  }
}
