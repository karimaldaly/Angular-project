import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { initializeApp,provideFirebaseApp } from '@angular/fire/app';
import { environment } from '../environments/environment';
import { provideFirestore,getFirestore } from '@angular/fire/firestore';
import { RouterModule, Routes } from '@angular/router';
import { SenderComponent } from './sender/sender.component';
import { RecieveComponent } from './recieve/recieve.component';
import { FormsModule } from '@angular/forms';

const appRoutes: Routes = [
  { path: "", component: SenderComponent },
  { path: "recieve", component: RecieveComponent },
  { path: "Dashboard", component: RecieveComponent }

];

@NgModule({
  declarations: [
    AppComponent,
    SenderComponent,
    RecieveComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoutes),
    provideFirebaseApp(() => initializeApp(environment.firebase)),
    provideFirestore(() => getFirestore())
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
