// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  firebase: {
    projectId: 'new-project-e06cf',
    appId: '1:380425266317:web:9d1de24a9c1447ff736ec4',
    storageBucket: 'new-project-e06cf.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyDmIluRQey9mAXofj2Ie3F6xOwNB2XTdPM',
    authDomain: 'new-project-e06cf.firebaseapp.com',
    messagingSenderId: '380425266317',
  },
  production: false
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
