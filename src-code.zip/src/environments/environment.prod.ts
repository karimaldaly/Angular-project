export const environment = {
  firebase: {
    projectId: 'new-project-e06cf',
    appId: '1:380425266317:web:9d1de24a9c1447ff736ec4',
    storageBucket: 'new-project-e06cf.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyDmIluRQey9mAXofj2Ie3F6xOwNB2XTdPM',
    authDomain: 'new-project-e06cf.firebaseapp.com',
    messagingSenderId: '380425266317',
  },
  production: true
};
